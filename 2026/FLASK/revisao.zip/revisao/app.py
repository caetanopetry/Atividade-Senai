from flask import Flask, render_template, request

app = Flask(__name__)

contatos = []

@app.route("/", methods=["GET", "POST"])
def main():
    if request.method == "POST":
        nome = request.form.get("nome")
        telefone = request.form.get("telefone")
        email = request.form.get("email")

        if nome and telefone and email:
            contatos.append({
                "nome": nome,
                "telefone": telefone,
                "email": email
            })

    return render_template("index.html")


@app.route("/contato")
def contato():
    return render_template("contato.html", contatos=contatos)

@app.route("/sobre")
def sobre():
    return render_template("sobre.html")

if __name__ == "__main__":
    app.run(debug=True)
