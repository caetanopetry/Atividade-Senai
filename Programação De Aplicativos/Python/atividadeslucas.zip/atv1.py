n = int (input("Digite o número que você deseja: "))

if n % 2 ==0:
    print("Número par")

else:
    print("Número Ímpar")