senha = "python"

tent = input("Digite a senha: ")

while tent != senha:
    print("SENHA ERRADA SEU BOBÃO!")
    tent = input("Digite a senha")

print("Você acertou sua senha.")