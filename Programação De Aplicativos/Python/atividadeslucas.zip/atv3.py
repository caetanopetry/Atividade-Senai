temp = int (input("Digite quantos graus está agora: "))

conversao = temp * 9/5 + 32

print(F"{temp}ºC em ºF é {conversao}")